# Mein Vorrat – PWA

Diese Version ist eine installierbare Web-App (PWA).

## So funktioniert sie

- Über HTTPS im Browser öffnen.
- Auf Android am besten Google Chrome verwenden.
- `Barcode scannen` öffnen.
- Barcode nur ins Kamerabild halten – kein Foto nötig.
- Nach erfolgreicher Erkennung werden Produktdaten über Open Food Facts gesucht.
- Menge, MHD, Lagerort und Notiz speichern.
- Die Daten bleiben lokal auf dem Gerät.

## Wichtig

Die Live-Kamera funktioniert nur in einem sicheren Kontext:
- HTTPS
- oder localhost

Eine lokal per `file://` geöffnete HTML-Datei reicht dafür nicht.

## Online stellen

Der komplette Inhalt dieses Ordners kann z. B. auf GitHub Pages, Netlify oder einem anderen HTTPS-Webspace veröffentlicht werden.

### GitHub Pages

1. Dateien dieses Ordners in ein GitHub-Repository hochladen.
2. Repository → Settings → Pages.
3. `Deploy from a branch` wählen.
4. Branch `main`, Ordner `/ (root)` wählen.
5. Speichern.
6. Nach kurzer Zeit erscheint dort die HTTPS-Adresse.

Danach die Seite auf dem Android-Handy in Chrome öffnen und über das Browser-Menü `App installieren` bzw. `Zum Startbildschirm hinzufügen` wählen.
